<?php
include "Header.php";
?>
<div id="wrapper">
	<div class="container">   
	<form >
	
	
	<div class="row">
    <div class="col-sm-12">
	<div class="form-group ">   
	
	<center><label for="comment"><h3>Employee-Dashboard<h3></label></center>
	<button type="button" class="btn btn-primary btn-lg" style="margin-left:1050px">View</button>
    <textarea class="form-control noresize" rows="10" id="encCss"></textarea>
    </div>
    </div>
	</div>
	
	
   <div class="row">
    <div class="col-sm-4" style="">
	<div class="form-group">
     <label for="sel1">Date </label></br>
     <input type="date" name="date"  id="date"  id="sell" /> 
     </div>	 
     </div>
 
  <div class="col-sm-4" style="">    
	<div class="form-group">
  <label for="sel1">Shift</label>
  <select class="form-control" id="sel1">
    <option>Morning</option>
    <option>Afternoon</option>
    <option>Night</option>
      </select>
   </div>
 </div>	

 <div class="col-sm-4" style="">
	<div class="form-group">
     <label for="file">File </label></br>
     <input type="file" name="file"  id="file" /> 
     </div>	 
 </div>
 </div>
	<div class="row"> 
	<div class="col-sm-4">	
	 </div>	 
	 <div class="col-md-4" style="margin-top:150px">
	 <button type="button" class="btn btn-primary btn-lg">Submit</button>
     <button type="button" class="btn btn-primary btn-lg">Reset</button>
	 </div>
	 </div>