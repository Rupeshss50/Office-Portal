 <?php
        include "Header.php";
 ?>


	<div id="wrapper">
	<div class="container">   
	<form action="home.php" method="post" autocomplete="off">
	<div class="row">
    <div class="col-sm-12">
	<div class="form-group ">   
	<center><label for="comment">Assign Work</label></center>
    <textarea class="form-control noresize" rows="10" id="work_details" name="work_details" required></textarea>
    </div>
    </div>
	</div>
	
   <div class="row">
    <div class="col-sm-3" style="">    
	<div class="form-group">
  <label for="empid">Employee Id</label>
  <select class="form-control" name="empid">
    <option>1000</option>
    <option>1001</option>
    <option>1002</option>
    <option>1003</option>
	<option>1004</option>
    <option>1005</option>
	<option>1006</option>
    <option>1007</option>
	<option>1008</option>
  </select>
   </div>
 </div>	
 
    <div class="col-sm-3" style="">
	<div class="form-group">
     <label for="date">Date </label></br>
     <input type="date" name="date"  id="date"  required /> 
     </div>	 
 </div>
 
  <div class="col-sm-3" style="">    
	<div class="form-group">
  <label for="shift">Shift</label>
  <select class="form-control" name="shift">
    <option>Morning</option>
    <option>Afternoon</option>
    <option>Night</option>
      </select>
   </div>
 </div>	

 
 <div class="col-sm-3" style="">
	<div class="form-group">
     <label for="file">File </label></br>
     <input type="file" name="file"  id="file" /> 
     </div>	 
 </div>
 
 </div>
 
	
	<div class="row"> 
	<div class="col-sm-4">	
	 </div>
	 
	 <div class="col-md-4" style="margin-top:150px">
	 <button type="submit" class="btn btn-primary btn-lg"  name="assign" >Assign</button>
     <button type="reset" class="btn btn-primary btn-lg">Reset</button>
	 </div>
	 </div>
	 
	 
	 </form>
	 </div>
	 </div>
	 
	 <?php
     error_reporting(E_ALL);
     ini_set('display_errors', 1);

    ?>
	 
    
     <?php	
      
           if(isset($_POST['assign'])) 
		   {          
		     
               $work_details = $_POST['work_details']; 			  
		       $empid = $_POST['empid'];
		       $date=$_POST['date']; 	
               $shift=$_POST['shift'];			   
			   $file=$_POST['file']; 			  
			   			  
				print "$work_details";	
                print "$empid" ;
                print "$date" ;
                print "$shift";
                print "$file";			   
						  
			   	require_once 'dbconnect.php';
				
			    $sql = "INSERT INTO tbl_employee VALUES ('$work_details','$empid',$date','$shift','$file');";      			 
			    $res = mysql_query($sql);				   
		        if ($res)
		        {
    			  echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
		        }
    		   else 
			   {
			       echo "<script type='text/javascript'>alert('error while processing!')</script>";
		       }	 
           
		    }
        
   ?>	
	
	
	
	
	
	
	