<?php
 include "Home.php";
?>


<?php
include 'dbconnect.php';
$selectRes=mysql_query('SELECT * FROM `tbl_customer_details`');
?>
 <style>

<style>
  body  {
          background-image: url("images/background1.jpg ");  
        }
		
		




 div.incidents {    
    margin: 50px 0px; 0px; 0;
    padding: 20px;
} 
</style>
 
 <div class="table-responsive">
 <div class="incidents" >
 <table class="table table-inverse table-bordered table-hover table-sm" border="1">
    <thead>
      <tr>
        <th>Name</th>
        <th>Address</th>
        <th>Purpose</th>
		<th>Mobile No.</th>
		<th>float </th>
		<th>Date</th>			
      </tr>
    </thead>
    <tbody>
	
	    <?php
         if( mysql_num_rows( $selectRes )==0 )
		 {
           echo '<tr><td colspan="4">No Rows Returned</td></tr>';
         }
	     else
		 {
        while( $row = mysql_fetch_assoc( $selectRes ) ){
          echo "<tr><td>{$row['name']}</td><td>{$row['address']}</td><td>{$row['purpose']}</td> <td>{$row['mobile_no']}</td><td>{$row['floatno']}</td> <td>{$row['date']}</td></tr>\n";
            }
            }
    ?>	  
    </tbody>	
  </table>

</div>
</div>